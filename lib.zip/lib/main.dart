import 'package:flutter/material.dart';
import 'package:flutter_train_app/pages/home/home_page.dart';
import 'package:flutter_train_app/theme.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // 애플리케이션의 루트 위젯
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // 시스템 설정에 따라 라이트/다크 테마 적용
      themeMode: ThemeMode.system,

      // 라이트 모드 테마 적용
      theme: theme,

      // 다크 모드 테마 적용
      darkTheme: darkTheme,

      // 앱 실행 시 처음 보여줄 페이지 (홈 페이지)
      home: HomePage(),
    );
  }
}
