import 'package:flutter/material.dart';
import 'package:flutter_train_app/pages/home/home_page.dart';

/// 기본 테마 설정
final theme = ThemeData(
  // 기본 색상 설정 (보라색 계열 적용)
  colorScheme: ColorScheme.fromSeed(seedColor: Colors.purple),

  // 전체 배경 색상 (연한 회색)
  scaffoldBackgroundColor: Colors.grey[200],

  // 카드 위젯의 배경 색상 (흰색)
  cardColor: Colors.white,

  // 비활성화된 요소의 색상 (연한 회색)
  disabledColor: Colors.grey[300],

  // ElevatedButton 스타일 설정
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ButtonStyle(
      // 버튼 모양 (모서리를 둥글게 처리)
      shape: WidgetStatePropertyAll(
        RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
      // 버튼 내부 텍스트 스타일 (굵은 18px 글자)
      textStyle: const WidgetStatePropertyAll(
        TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
      // 버튼 배경 색상 (보라색)
      backgroundColor: const WidgetStatePropertyAll(Colors.purple),
      // 버튼 글자 색상 (흰색)
      foregroundColor: const WidgetStatePropertyAll(Colors.white),
    ),
  ),
);

/// 다크 모드 테마 설정
final darkTheme = ThemeData(
  // 기본 색상 설정 (보라색 계열, 다크 모드 적용)
  colorScheme: ColorScheme.fromSeed(
    seedColor: Colors.purple,
    brightness: Brightness.dark,
  ),

  // 카드 위젯의 배경 색상 (진한 회색)
  cardColor: Colors.grey[800],

  // 비활성화된 요소의 색상 (어두운 회색)
  disabledColor: Colors.grey[700],

  // ElevatedButton 스타일 설정 (기본 테마와 동일)
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ButtonStyle(
      shape: WidgetStatePropertyAll(
        RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
      textStyle: const WidgetStatePropertyAll(
        TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
      backgroundColor: const WidgetStatePropertyAll(Colors.purple),
      foregroundColor: const WidgetStatePropertyAll(Colors.white),
    ),
  ),
);
