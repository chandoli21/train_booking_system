import 'package:flutter/material.dart';

// 모든 역 목록
final List<String> allStations = [
  "수서",
  "동탄",
  "평택지제",
  "천안아산",
  "오송",
  "대전",
  "김천구미",
  "동대구",
  "경주",
  "울산",
  "부산",
];

class StationListPage extends StatelessWidget {
  const StationListPage({
    super.key,
    required this.title,
    required this.ignoreStation,
  });

  final String title; // 페이지 제목
  final String? ignoreStation; // 제외할 역 (선택적)

  @override
  Widget build(BuildContext context) {
    // 제외할 역을 필터링하여 새로운 목록 생성
    final List<String> stations =
        allStations.where((station) => station != ignoreStation).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: ListView.builder(
        itemCount: stations.length,
        itemBuilder: (context, index) {
          return StationTile(
            stationName: stations[index],
            onTap: () =>
                Navigator.pop(context, stations[index]), // 역 선택 시 이전 화면으로 값 반환
          );
        },
      ),
    );
  }
}

// 개별 역 항목을 위한 위젯 (코드를 모듈화하기 위해 분리)
class StationTile extends StatelessWidget {
  const StationTile({
    super.key,
    required this.stationName,
    required this.onTap,
  });

  final String stationName; // 역 이름
  final VoidCallback onTap; // 탭 이벤트 핸들러

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(
        stationName,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      onTap: onTap, // 역 선택 시 실행
      shape: const Border(
        bottom: BorderSide(
          color: Color(0xFFE0E0E0), // 연한 회색 하단 테두리
        ),
      ),
    );
  }
}
