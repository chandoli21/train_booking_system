import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_train_app/pages/seat/widgets/departure_arrival_box.dart';
import 'package:flutter_train_app/pages/seat/widgets/seat_label_box.dart';
import 'package:flutter_train_app/pages/seat/widgets/seat_list_view.dart';

class SeatPage extends StatefulWidget {
  const SeatPage({
    super.key,
    required this.departure,
    required this.arrival,
  });

  // 출발역 이름
  final String departure;

  // 도착역 이름
  final String arrival;

  @override
  State<SeatPage> createState() => _SeatPageState();
}

class _SeatPageState extends State<SeatPage> {
  int? selectedRow; // 선택된 좌석의 행 번호
  int? selectedCol; // 선택된 좌석의 열 번호

  // 좌석의 열을 나타내는 라벨 목록
  static const List<String> seatColumns = ['', 'A', 'B', 'C', 'D'];

  // 좌석 선택 시 상태를 업데이트하는 함수
  void onSelected(int row, int col) {
    setState(() {
      selectedRow = row;
      selectedCol = col;
    });
  }

  // 좌석 예매 확인 다이얼로그를 표시하는 함수
  void showConfirmationDialog(BuildContext context) {
    if (selectedRow == null || selectedCol == null) return;

    // 좌석 열 인덱스가 유효한지 확인한 후 표시
    final String colName = (selectedCol! > 0 && selectedCol! < seatColumns.length)
        ? seatColumns[selectedCol!]
        : '?';

    showCupertinoDialog(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: const Text("예매 하시겠습니까?"),
        content: Text('좌석 : $selectedRow-$colName'),
        actions: [
          // 취소 버튼
          CupertinoDialogAction(
            onPressed: () => Navigator.pop(context),
            child: const Text("취소", style: TextStyle(color: Colors.red)),
          ),
          // 확인 버튼 (예매 후 이전 화면으로 돌아감)
          CupertinoDialogAction(
            onPressed: () {
              Navigator.pop(context); // 다이얼로그 닫기
              Navigator.pop(context); // 이전 페이지로 이동
            },
            child: const Text("확인", style: TextStyle(color: Colors.blue)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('좌석 선택')),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          children: [
            // 출발역과 도착역 정보를 표시하는 위젯
            DepartureArrivalBox(
              departure: widget.departure,
              arrival: widget.arrival,
            ),
            const SizedBox(height: 10),

            // 좌석 상태를 설명하는 라벨 박스 (예: "선택됨", "사용 가능")
            const SeatLabelBox(),

            // 좌석 선택 리스트
            SeatListView(
              selectedRow: selectedRow,
              selectedCol: selectedCol,
              onSelected: onSelected,
            ),

            // 예매 버튼
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: () => showConfirmationDialog(context),
                child: const Text("예매 하기"),
              ),
            ),

            const SizedBox(height: 50),
          ],
        ),
      ),
    );
  }
}
