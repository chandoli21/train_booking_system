import 'package:flutter/material.dart';

/// 출발역과 도착역을 표시하는 위젯
/// - 선택된 출발역과 도착역을 화면 중앙에 배치.
/// - 두 역 사이에 화살표(➡) 아이콘을 배치하여 직관적인 UI 제공.
class DepartureArrivalBox extends StatelessWidget {
  const DepartureArrivalBox({
    super.key,
    required this.departure,
    required this.arrival,
  });

  /// 출발역 (필수 입력값)
  final String departure;

  /// 도착역 (필수 입력값)
  final String arrival;

  @override
  Widget build(BuildContext context) {
    return DefaultTextStyle(
      /// 모든 역 이름에 동일한 스타일 적용
      style: const TextStyle(
        color: Colors.purple, // 보라색 텍스트
        fontWeight: FontWeight.bold, // 볼드체
        fontSize: 30, // 글자 크기 30
      ),
      child: Row(
        /// 출발역과 도착역을 중앙 정렬하고, 사이에 화살표 배치
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          /// 출발역 이름
          Expanded(
            child: Center(
              child: Text(departure),
            ),
          ),

          /// 출발역과 도착역을 연결하는 화살표 아이콘
          const Icon(
            Icons.arrow_circle_right_outlined, // 아이콘 모양
            size: 30, // 크기 30
          ),

          /// 도착역 이름
          Expanded(
            child: Center(
              child: Text(arrival),
            ),
          ),
        ],
      ),
    );
  }
}
