import 'package:flutter/material.dart';

/// 좌석 상태(예: 선택됨, 이용 불가)를 나타내는 라벨 위젯.
class SeatLabelBox extends StatelessWidget {
  const SeatLabelBox({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      /// 좌석 라벨을 가로 방향으로 중앙 정렬.
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        /// "선택됨" 상태를 나타내는 보라색 좌석 라벨.
        seatLabel('선택됨', Colors.purple),

        const SizedBox(width: 20),

        /// "이용 불가" 상태를 나타내는 비활성화된 좌석 라벨.
        seatLabel('이용 불가', Theme.of(context).disabledColor),
      ],
    );
  }

  /// 색상이 적용된 좌석 라벨을 생성하는 함수.
  Row seatLabel(String label, Color color) {
    return Row(
      children: [
        /// 좌석 상태를 나타내는 색상 박스.
        Container(
          width: 24,
          height: 24,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(8), // 둥근 모서리 적용
          ),
        ),
        const SizedBox(width: 4),

        /// 좌석 상태를 설명하는 텍스트.
        Text(label),
      ],
    );
  }
}
