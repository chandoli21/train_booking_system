import 'package:flutter/material.dart';

/// 좌석을 선택할 수 있는 목록 위젯.
/// 행과 열로 정렬된 좌석을 표시하며, 사용자가 선택할 수 있음.
class SeatListView extends StatelessWidget {
  const SeatListView({
    super.key,
    required this.selectedRow,
    required this.selectedCol,
    required this.onSelected,
  });

  /// 현재 선택된 행 (없으면 null)
  final int? selectedRow;

  /// 현재 선택된 열 (없으면 null)
  final int? selectedCol;

  /// 좌석 선택 시 호출되는 콜백 함수.
  final void Function(int row, int col) onSelected;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ListView(
        padding: const EdgeInsets.symmetric(vertical: 20),
        children: [
          columnLabels(), // 열 레이블 (A, B, C, D)
          ...List.generate(20, (i) => row(context, i + 1)), // 20개의 좌석 행 생성
        ],
      ),
    );
  }

  /// 좌석 열(A, B, C, D) 레이블을 생성하는 위젯
  Row columnLabels() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        listLabel('A'),
        const SizedBox(width: 4),
        listLabel('B'),
        const SizedBox(width: 4),
        listLabel(''), // 좌우 섹션 구분 공백
        const SizedBox(width: 4),
        listLabel('C'),
        const SizedBox(width: 4),
        listLabel('D'),
      ],
    );
  }

  /// 열 또는 행 번호 레이블을 생성하는 위젯
  SizedBox listLabel(String label) {
    return SizedBox(
      width: 50,
      child: Center(
        child: Text(
          label,
          style: const TextStyle(fontSize: 18),
        ),
      ),
    );
  }

  /// 특정 행의 좌석을 생성하는 위젯
  Widget row(BuildContext context, int rowNum) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          seat(context, rowNum, 1),
          const SizedBox(width: 4),
          seat(context, rowNum, 2),
          const SizedBox(width: 4),
          listLabel('$rowNum'), // 가운데 행 번호
          const SizedBox(width: 4),
          seat(context, rowNum, 3),
          const SizedBox(width: 4),
          seat(context, rowNum, 4),
        ],
      ),
    );
  }

  /// 개별 좌석을 생성하는 위젯
  Widget seat(BuildContext context, int rowNum, int colNum) {
    return GestureDetector(
      onTap: () => onSelected(rowNum, colNum), // 좌석 선택 시 콜백 호출
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          color: selectedRow == rowNum && selectedCol == colNum
              ? Colors.purple // 선택된 좌석 색상
              : Theme.of(context).disabledColor, // 기본 색상
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }
}
