import 'package:flutter/material.dart';
import 'package:flutter_train_app/pages/home/widgets/station_box.dart';
import 'package:flutter_train_app/pages/seat/seat_page.dart';

/// 🚆 **기차 예매 홈 화면**
/// - 사용자가 출발역과 도착역을 선택할 수 있음.
/// - 선택된 역을 바탕으로 좌석 선택 화면으로 이동 가능.
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  /// 출발역 (선택되지 않았을 경우 `null`)
  String? departure;

  /// 출발역이 변경될 때 실행되는 함수
  /// - 새로운 역이 선택되면 `departure` 상태를 업데이트.
  void onDepartureChanged(String v) {
    setState(() {
      departure = v;
    });
  }

  /// 도착역 (선택되지 않았을 경우 `null`)
  String? arrival;

  /// 도착역이 변경될 때 실행되는 함수
  /// - 새로운 역이 선택되면 `arrival` 상태를 업데이트.
  void onArrivalChanged(String v) {
    setState(() {
      arrival = v;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('기차 예매'), // 앱 상단 제목
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20), // 좌우 여백 추가
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            /// 🚉 출발역 및 도착역 선택 위젯
            StateBox(
              departure: departure,
              arrival: arrival,
              onDepartureChanged: onDepartureChanged,
              onArrivalChanged: onArrivalChanged,
            ),
            const SizedBox(height: 20),

            /// 좌석 선택 버튼
            /// - 출발역과 도착역이 모두 선택되었을 경우에만 `SeatPage`로 이동 가능.
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: () {
                  if (departure != null && arrival != null) {
                    // 출발역과 도착역이 선택된 경우에만 다음 화면으로 이동
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) {
                          return SeatPage(
                            departure: departure!,
                            arrival: arrival!,
                          );
                        },
                      ),
                    );
                  }
                },
                child: const Text('좌석 선택'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
