import 'package:flutter/material.dart';
import 'package:flutter_train_app/pages/station_list/station_list_page.dart';

/// 출발역과 도착역을 선택할 수 있는 UI 위젯.
/// - 사용자가 출발역과 도착역을 선택하면 콜백을 통해 변경 사항을 전달.
/// - 선택된 역을 표시하고, 역 선택 화면으로 이동할 수 있음.
class StateBox extends StatelessWidget {
  const StateBox({
    super.key,
    required this.departure, // 출발역 (선택되지 않았을 경우 null)
    required this.arrival, // 도착역 (선택되지 않았을 경우 null)
    required this.onDepartureChanged, // 출발역이 변경될 때 실행할 콜백 함수
    required this.onArrivalChanged, // 도착역이 변경될 때 실행할 콜백 함수
  });

  final String? departure;
  final String? arrival;
  final void Function(String) onDepartureChanged;
  final void Function(String) onArrivalChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 200,
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor, // 테마의 카드 색상 적용
        borderRadius: BorderRadius.circular(20), // 둥근 모서리 적용
      ),
      child: Row(
        children: [
          // 출발역 선택 타일
          _StationTile(
            label: '출발역',
            selectedStation: departure,
            onChanged: onDepartureChanged,
            ignoreStation: arrival, // 도착역과 동일한 역을 선택하지 못하도록 설정
          ),
          _divider(), // 구분선
          // 도착역 선택 타일
          _StationTile(
            label: '도착역',
            selectedStation: arrival,
            onChanged: onArrivalChanged,
            ignoreStation: departure, // 출발역과 동일한 역을 선택하지 못하도록 설정
          ),
        ],
      ),
    );
  }

  /// 출발역과 도착역을 구분하는 시각적 요소 (세로선).
  Widget _divider() => Container(
        width: 2,
        height: 50,
        color: Colors.grey[400], // 연한 회색의 구분선 적용
      );
}

/// 선택 가능한 역을 나타내는 위젯.
/// - `_StationTile`은 `StateBox` 내부에서 사용되며, 출발역 또는 도착역을 선택하는 역할.
/// - 사용자가 터치하면 `StationListPage`로 이동하여 역을 선택할 수 있음.
class _StationTile extends StatelessWidget {
  const _StationTile({
    required this.label, // '출발역' 또는 '도착역'을 나타내는 라벨
    required this.selectedStation, // 현재 선택된 역 (선택되지 않았을 경우 null)
    required this.onChanged, // 사용자가 역을 선택했을 때 실행할 콜백 함수
    required this.ignoreStation, // 선택하지 못하도록 제외할 역 (출발역 ↔ 도착역 중복 방지)
  });

  final String label;
  final String? selectedStation;
  final void Function(String) onChanged;
  final String? ignoreStation;

  /// 역 선택 화면(`StationListPage`)으로 이동하여 사용자가 역을 선택할 수 있도록 함.
  /// - 선택한 역을 `onChanged` 콜백을 통해 상위 위젯에 전달.
  Future<void> _selectStation(BuildContext context) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => StationListPage(
          title: label, // 화면 제목 (출발역 / 도착역)
          ignoreStation: ignoreStation, // 선택할 수 없는 역 (출발역 ↔ 도착역 중복 방지)
        ),
      ),
    );
    if (result != null) onChanged(result); // 선택한 역을 상위 위젯으로 전달
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: () => _selectStation(context), // 사용자가 터치하면 역 선택 화면으로 이동
        child: Container(
          color: Colors.transparent, // 터치 영역을 확장하기 위해 투명한 배경 사용
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                label, // '출발역' 또는 '도착역' 표시
                style: const TextStyle(
                  fontSize: 16,
                  color: Colors.grey,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                selectedStation ?? '선택', // 선택된 역이 없으면 '선택' 텍스트 표시
                style: const TextStyle(fontSize: 40),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
