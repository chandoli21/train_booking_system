# Flutter Train Reservation Service

## 프로젝트 개요
이 프로젝트는 플러터(Flutter)를 사용하여 간단한 기차 예매 시스템을 구현한 것입니다. 사용자는 출발역과 도착역을 선택한 후 좌석을 예매할 수 있습니다.

## 기능
- 출발역 및 도착역 선택
- 좌석 선택 및 예매
- 선택된 좌석에 대한 확인 팝업 제공

## 프로젝트 구조
```
lib/
│── pages/
│   ├── home/
│   │   ├── widgets/
│   │   │   ├── station_box.dart
│   │   ├── home_page.dart
│   ├── seat/
│   │   ├── widgets/
│   │   │   ├── departure_arrival_box.dart
│   │   │   ├── seat_label_box.dart
│   │   │   ├── seat_list_view.dart
│   │   ├── seat_page.dart
│   ├── station_list/
│   │   ├── station_list_page.dart
│── main.dart
│── theme.dart
```

## 사용 방법
1. `main.dart` 파일을 실행하여 앱을 시작합니다.
2. 출발역과 도착역을 선택합니다.
3. 좌석을 선택한 후 확인 버튼을 눌러 예매를 진행합니다.

## 기술 스택
- Flutter
- Dart

---

# Flutter Train Reservation Service

## Project Overview
This project is a simple train reservation system built with Flutter. Users can select departure and arrival stations and book seats.

## Features
- Select departure and arrival stations
- Choose and book seats
- Confirmation popup for selected seats

## Project Structure
```
lib/
│── pages/
│   ├── home/
│   │   ├── widgets/
│   │   │   ├── station_box.dart
│   │   ├── home_page.dart
│   ├── seat/
│   │   ├── widgets/
│   │   │   ├── departure_arrival_box.dart
│   │   │   ├── seat_label_box.dart
│   │   │   ├── seat_list_view.dart
│   │   ├── seat_page.dart
│   ├── station_list/
│   │   ├── station_list_page.dart
│── main.dart
│── theme.dart
```

## How to Use
1. Run the `main.dart` file to start the app.
2. Select departure and arrival stations.
3. Choose a seat and proceed with the reservation.

## Tech Stack
- Flutter
- Dart

